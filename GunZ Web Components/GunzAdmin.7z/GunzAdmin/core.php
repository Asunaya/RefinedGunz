<?PHP

require_once( dirname(__FILE__).DIRECTORY_SEPARATOR.'conf.php' );
require_once( dirname(__FILE__).DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'mssql.class.php' );
require_once( dirname(__FILE__).DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'helper_api.php' );
require_once( dirname(__FILE__).DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'view_api.php' );
require_once( dirname(__FILE__).DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'db_api.php' );

?>
